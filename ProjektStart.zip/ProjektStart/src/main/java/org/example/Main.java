package org.example;

public class Main {
    public static void main(String[] args) {

        Technician tomek = new Technician("tomek1","123");
        tomek.register();
        tomek.login();


    }
}