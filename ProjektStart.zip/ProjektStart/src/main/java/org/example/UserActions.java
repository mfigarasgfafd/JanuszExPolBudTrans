package org.example;

public interface UserActions {
    public String login();
    public void register();
}
